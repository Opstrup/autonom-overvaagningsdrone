/*
 * This class handels the logic behind the archive
 * function
 */

'use strict';

angular
  .module('frontend')
  .controller('archiveCtrl', ['$scope', function($scope) {
    $scope.title = "Archive";
    
  }]);